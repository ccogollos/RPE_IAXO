#!bin/bash

restPrintRunInfo ../data/IAXOD0/Argon_AGET_closer/U238_Chip/Run_simulation_U238fromChipVolume_00096_Version_2.1.6.root

restPrintRunInfo ../data/IAXOD0/Argon_AGET_closer/U238_Chip/Run_simulation_U238fromChipVolume_00098_Version_2.1.6.root