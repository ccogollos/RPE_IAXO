#!/bin/bash

#

#SBATCH -J  AnalysisTrackIsotopeFromChip               # job name
#SBATCH -o  AnalysisTrackIsotopeFromChip.o%j           # output and error file name (%j expands to jobID)
#SBATCH --mail-user cotri.ferm@gmail.com
#SBATCH --mail-type=ALL
#SBATCH -p bifi                # queue (partition) 

# User specific aliases and functions
#module load slurm
#module load root/5.34
#module load gcc/5.1.0
#module load geant/4.10.02
#module load python/2.7.12

#source /home/zar30001/garfield/install/garfield.sh
#export CXX=/cm/local/apps/gcc/5.1.0/bin/c++
#export G4INSTALL=/cm/shared/apps/geant/4.10.02
#source $G4INSTALL/bin/geant4.sh
#source $HOME/REST_v2/install/thisREST.sh

source ~/.bashrc

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00113_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00121_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00125_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00130_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00131_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00133_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00138_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00139_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00144_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00145_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00146_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00147_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00152_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00156_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00158_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00169_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00170_Version_2.1.6.root

restManager --c /home/zar30001/cristian/AGET_Sims/IAXOD0_AGET-REST/G4sims/restProcesses/restSimManagerK40Chip_closer.rml --f /home/zar30001/cristian/AGET_Sims/data/IAXOD0/Argon_AGET_closer/K40_Chip/Run_simulation_K40fromChipVolume_00171_Version_2.1.6.root